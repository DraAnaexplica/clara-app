git add .
git commit -m "🟢 Atualização automática"
git push origin main
